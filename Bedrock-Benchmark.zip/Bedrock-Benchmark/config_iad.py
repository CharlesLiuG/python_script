from urllib.parse import quote

REGION = 'us-east-1'
# REGION = 'us-west-2'

HOST = f'bedrock-runtime.{REGION}.amazonaws.com'

# MODEL_ID = 'amazon.nova-micro-v1:0'
MODEL_ID = 'amazon.nova-lite-v1:0'
# MODEL_ID = 'amazon.nova-pro-v1:0'
# MODEL_ID = 'amazon.nova-canvas-v1:0'

# /model/modelId/invoke
BEDROCK_ENDPOINT_URL = f'https://{HOST}/model/{MODEL_ID}/invoke'
BEDROCK_ENDPOINT_STREAM_URL = f'https://{HOST}/model/{MODEL_ID}/invoke-with-response-stream'

ACCESS_KEY = 'AKIAVJYQXYHPUFZTOPTR'
SECRET_KEY = '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'

CONTENT_TYPE = 'application/json'
METHOD = 'POST'
SERVICE = 'bedrock'
SIGNED_HEADERS = 'host;x-amz-date'
CANONICAL_QUERY_STRING = ''
ALGORITHM = 'AWS4-HMAC-SHA256'
