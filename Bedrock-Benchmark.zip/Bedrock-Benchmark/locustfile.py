# -*- coding: utf-8 -*-
from locust import HttpUser, task, constant_throughput, events
from contextlib import ContextDecorator, contextmanager
from authorizer import authorize, get_payload_hash
import config_iad as conf
import time
import json
import base64
import re
import locust.stats
locust.stats.PERCENTILES_TO_STATISTICS = [0.95, 0.98, 0.99]

# ref: https://github.com/locustio/locust/blob/master/examples/manual_stats_reporting.py
@contextmanager
def _manual_report(name, value):
    try:
        yield
    except Exception as e:
        events.request.fire(
            request_type="manual",
            name=name,
            response_time=value,
            response_length=0,
            exception=e,
        )
        raise
    else:
        events.request.fire(
            request_type="manual",
            name=name,
            response_time=value,
            response_length=0,
            exception=None,
        )


def manual_report(name_or_func, value):
    if callable(name_or_func):
        # used as decorator without name argument specified
        return _manual_report(name_or_func.__name__)(name_or_func, value)
    else:
        return _manual_report(name_or_func, value)

sp = open('payload-fc-system.txt').read()
PAYLOAD_0 =  json.dumps({
    "schemaVersion": "messages-v1",
    "system": [{"text": sp}],
    "messages": [{"role": "user", "content": [{"text": """write a 800 words text about yellow river."""}]}],
    "inferenceConfig": {"max_new_tokens": 180, "top_p": 0.9, "temperature": 0.7},
})


payload_hash = get_payload_hash(PAYLOAD_0)

class WebsiteUser(HttpUser):
    # task run x times per second
    wait_time = constant_throughput(4)

    # @task
    def test_post(self):
        global payload_hash
        """
        Load Test Bedrock Endpoint (POST request)
        """
        headers = authorize(PAYLOAD_0, payload_hash)
        resp = self.client.post(conf.BEDROCK_ENDPOINT_URL, data=PAYLOAD_0, headers=headers, name='Post Request')

        if resp.status_code != 200:
            print(resp, resp.reason)
            time.sleep(1)
        else:
            # print("Response status code:", resp.status_code)
            resp_body = json.loads(resp.text)
            assist = resp_body['content'][0]['text']
            usage = resp_body['usage']
            input_tokens = usage['input_tokens']
            output_tokens = usage['output_tokens']

            with manual_report('inputToken', input_tokens):
              pass
            with manual_report('outToken', output_tokens):
              pass
            # print(f"Response. [Len: {len(assist)}]", assist[:10])

    @task
    def test_post_stream(self):
        global payload_hash
        """
        Load Test Bedrock Endpoint (POST request)
        """
        start_time = time.time() * 1000
        headers = authorize(PAYLOAD_0, payload_hash, True)
        resp = self.client.post(conf.BEDROCK_ENDPOINT_STREAM_URL, data=PAYLOAD_0, headers=headers, name='Post Request')

        if resp.status_code != 200:
            print(resp, resp.reason)
            time.sleep(1)
        else:
            stat = resp.text.split('event')[-1]
            try:
                result = re.search('bytes":"(.*)"', stat).group(1).split('"')[0]
                stat = json.loads(base64.b64decode(result).decode())['amazon-bedrock-invocationMetrics']
                # print(stat)

                with manual_report('[E2E]invocationLatency', time.time() * 1000 - start_time):
                    pass
                
                with manual_report('invocationLatency', stat['invocationLatency']):
                    pass
                
                with manual_report('firstByteLatency', stat['firstByteLatency']):
                    pass

                with manual_report('perTokenLatency', (stat['invocationLatency'] - stat['firstByteLatency']) / stat['outputTokenCount']):
                    pass

                with manual_report('inputTokens', stat['inputTokenCount']):
                    pass

                with manual_report('outputTokens', stat['outputTokenCount']):
                    pass
            except:
                print(stat)
                print('---' * 10)

            # print(resp.text)
            # resp_body = json.loads()
            # assist = resp_body['content'][0]['text']
            # usage = resp_body['usage']
            # input_tokens = usage['input_tokens']
            # output_tokens = usage['output_tokens']

def local_test():
    import http.client
    conn = http.client.HTTPSConnection(conf.HOST)
    headers = authorize(PAYLOAD_0)

    conn.request('POST', f'/model/{conf.MODEL_ID}/invoke', PAYLOAD_0, headers)

    response = conn.getresponse()
    resp_body = json.loads(response.read().decode())
    print(resp_body)
    print(resp_body['content'][0]['text'])
    usage = resp_body['usage']
    print(usage)
    # print(resp_body)
    # headers = authorize(PAYLOAD, payload_hash)
    # resp = self.client.post(conf.BEDROCK_ENDPOINT_URL, data=PAYLOAD, headers=headers, name='Post Request')


def local_test_stream():
    import http.client
    conn = http.client.HTTPSConnection(conf.HOST)
    headers = authorize(PAYLOAD_0, payload_hash, True)
    # print(headers)

    conn.request('POST', f'/model/{conf.MODEL_ID}/invoke-with-response-stream', PAYLOAD_0, headers)

    response = conn.getresponse()
    resp = response.read()
    print(resp)
    stat = str(resp).split('event')[-1]
    result = re.search('bytes":"(.*)"', stat).group(1).split('"')[0]
    stat = json.loads(base64.b64decode(result).decode())#['amazon-bedrock-invocationMetrics']
    print(stat)
    # print(resp_body['content'][0]['text'])
    # usage = resp_body['usage']
    # print(usage)

if __name__ == '__main__':
    import logging

    logger = logging.getLogger('my-authorizer')
    logger.setLevel(logging.WARNING)
    logger.setLevel(logging.INFO)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    # 添加处理器到记录器
    logger.addHandler(console_handler)

    local_test_stream()
    #local_test()
    # local_test_image()
